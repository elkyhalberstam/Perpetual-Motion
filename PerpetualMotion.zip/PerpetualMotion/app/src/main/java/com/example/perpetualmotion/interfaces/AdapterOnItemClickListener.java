package com.example.perpetualmotion.interfaces;

import android.view.View;

public interface AdapterOnItemClickListener {
    void onItemClick (int position, View viewClicked);
}
